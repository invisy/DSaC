﻿using DSaC_LAB1.Client.Core;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Logging;
using System.Net;

namespace DSaC_LAB1.Server.CLI;

public class Program
{
    public static async Task Main(string[] args)
    {
        var serviceProvider = new ServiceCollection()
            //.AddSingleton<Controller, Controller>()
            /*.AddLogging(builder => builder
                            .ClearProviders()
                            .AddColorConsoleLogger()
                            .AddFilter(level => level >= LogLevel.Debug))*/
            .BuildServiceProvider();

        /*var logger = serviceProvider.GetService<ILoggerFactory>()
            .CreateLogger<Program>();
        logger.LogDebug("Starting application");*/

        SocketClient client = new SocketClient(IPAddress.Parse("192.168.31.8"), 11000);
        client.DataReceived += OnReceivedMessage;
        await client.Connect();

        while (true)
        {
            string input = Console.ReadLine() ?? String.Empty;
            if (input.Equals("exit"))
                break;
            else
            {
                int bytesSent = await client.Send(input);
                Console.WriteLine("Sent {0} bytes to client.", bytesSent);
            }

        }

        //logger.LogDebug("Closing application!");
        serviceProvider.Dispose();
    }

    private static void OnReceivedMessage(string data)
    {
        Console.WriteLine($"Received from server: {data}");
    }
}