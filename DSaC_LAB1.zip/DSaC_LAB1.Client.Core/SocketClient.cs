﻿using System.Text;
using System.Net;
using System.Net.Sockets;

namespace DSaC_LAB1.Client.Core;

public class StateObject
{
    public const int BufferSize = 1024;
    public byte[] buffer { get; } = new byte[BufferSize];
    public StringBuilder sb { get; } = new();

    public void Clean()
    {
        Array.Clear(buffer);
        sb.Clear();
    }
}

public class SocketClient : IDisposable
{
    private readonly IPEndPoint _endPoint;
    private readonly Socket _client;

    public delegate void ReceiveDelegate(string data);
    public event ReceiveDelegate DataReceived;

    public SocketClient(IPAddress address, int port)
    {
        _endPoint = new IPEndPoint(address, port);
        _client = new Socket(_endPoint.AddressFamily, SocketType.Stream, ProtocolType.Tcp);
    }

    public Task Connect()
    {
        Task connectTask = Task.Factory.FromAsync(
                _client.BeginConnect(_endPoint, null, null),
                _client.EndConnect
        );

        return connectTask.ContinueWith(_ =>
            {
                StateObject state = new();
                _client.BeginReceive(state.buffer, 0, StateObject.BufferSize, 0, new AsyncCallback(ReceiveCallback), state);
            }
        );
    }

    private void ReceiveCallback(IAsyncResult asyncResult)
    {
        StateObject state = (StateObject) asyncResult.AsyncState;
        int bytesRead = _client.EndReceive(asyncResult);

        if (bytesRead > 0)
        {
            state.sb.Append(Encoding.Unicode.GetString(state.buffer, 0, bytesRead));

            if (_client.Available <= bytesRead)
            {
                DataReceived?.Invoke(state.sb.ToString());
                state.Clean();
            }

            _client.BeginReceive(state.buffer, 0, StateObject.BufferSize, 0, new AsyncCallback(ReceiveCallback), state);
        }
    }

    public Task<int> Send(String data)
    {
        byte[] byteData = Encoding.Unicode.GetBytes(data);

        return Task.Factory.FromAsync<int>(
                _client.BeginSend(byteData, 0, byteData.Length, 0, null, null),
                _client.EndSend
        );
    }

    public void Close()
    {
        Dispose();
    }

    public void Dispose()
    {
        _client.Shutdown(SocketShutdown.Both);
        _client.Close();
    }
}
