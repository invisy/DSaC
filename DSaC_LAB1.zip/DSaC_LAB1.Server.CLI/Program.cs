﻿using DSaC_LAB1.Server.CLI.Logger;
using DSaC_LAB1.Server.Core;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Logging;

namespace DSaC_LAB1.Server.CLI;

public class Program
{
    public static async Task Main(string[] args)
    {
        var serviceProvider = new ServiceCollection()
            .AddSingleton<SocketServer, SocketServer>()
            .AddLogging(builder => builder
                            .ClearProviders()
                            .AddColorConsoleLogger()
                            .AddFilter(level => level >= LogLevel.Debug))
            .BuildServiceProvider();

        var logger = serviceProvider.GetService<ILoggerFactory>()
            .CreateLogger<Program>();
        logger.LogDebug("Starting application");

        SocketServer server = serviceProvider.GetService<SocketServer>();
        server.DataReceived += OnReceivedMessage;
        server.StartListening();

        while(true)
        {
            string input = Console.ReadLine() ?? String.Empty;
            if (input.Equals("exit"))
                break;
            else
            {
                int bytesSent = await server.Send(input);
                Console.WriteLine("Sent {0} bytes to client.", bytesSent);
            }

        }

        logger.LogDebug("Closing application!");
        serviceProvider.Dispose();
    }

    private static void OnReceivedMessage(string data)
    {
        Console.WriteLine($"Received from client: {data}");
    }

    /*public interface ISocketServer
    {
        Task<int> Send(Client client, string input);
        Task<Клас з клієнтом і даними> Receive();
        Task StartListening();
    }*/
}