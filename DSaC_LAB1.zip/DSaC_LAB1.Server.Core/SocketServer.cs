﻿using System.Net;
using System.Net.Sockets;
using System.Text;
using Microsoft.Extensions.Logging;
using System.Collections.Concurrent;

namespace DSaC_LAB1.Server.Core;

public class StateObject
{
    public Socket clientSocket = null;
    public const int BufferSize = 1024;
    public byte[] buffer = new byte[BufferSize];
    public StringBuilder sb = new();

    public void Clean()
    {
        Array.Clear(buffer);
        sb.Clear();
    }
}

public class SocketServer : IDisposable
{
    private readonly IPEndPoint _localEndPoint;
    private readonly Socket _listener;
    private readonly ConcurrentDictionary<EndPoint, Socket> _clients = new();
    private readonly ILogger<SocketServer> _logger;

    public delegate void ReceiveDelegate(string data);
    public event ReceiveDelegate DataReceived;

    public SocketServer(ILogger<SocketServer> logger)
    {
        _localEndPoint = new IPEndPoint(IPAddress.Any, 11000);
        _listener = new Socket(_localEndPoint.AddressFamily, SocketType.Stream, ProtocolType.Tcp);
        _logger = logger;
    }

    public void StartListening()
    {
        ///try
        //{
            _listener.Bind(_localEndPoint);
            _listener.Listen(100);

            _logger.LogDebug("Waiting for a connection...");

            Task listening = Task.Run(async () =>
            {
                while (true)
                    await Accept();
            });

        /*}
        catch (Exception e)
        {
            _logger.LogError(e.ToString());
        }*/
    }

    private Task Accept()
    {
        Task<Socket> acceptTask = Task.Factory.FromAsync<Socket>(
                _listener.BeginAccept(null, null),
                _listener.EndAccept
            );

        return acceptTask.ContinueWith(async (socket) =>
            {
                Socket client = socket.Result;
                _clients.TryAdd(client.RemoteEndPoint, client);

                StateObject state = new();
                state.clientSocket = client;
                client.BeginReceive(state.buffer, 0, StateObject.BufferSize, 0, new AsyncCallback(ReceiveCallback), state);
            }
        );
    }

    private void ReceiveCallback(IAsyncResult asyncResult)
    {
        StateObject state = (StateObject)asyncResult.AsyncState;
        Socket client = state.clientSocket;
        int bytesRead = client.EndReceive(asyncResult);

        if (bytesRead > 0)
        {
            state.sb.Append(Encoding.Unicode.GetString(state.buffer, 0, bytesRead));

            if (client.Available <= bytesRead)
            {
                DataReceived?.Invoke(state.sb.ToString());
                state.Clean();
            }
            
            client.BeginReceive(state.buffer, 0, StateObject.BufferSize, 0, new AsyncCallback(ReceiveCallback), state);
        }
    }

    public Task<int> Send(string data)
    {
        Socket handler = _clients.Values.First();
        byte[] byteData = Encoding.Unicode.GetBytes(data);

        return Task.Factory.FromAsync<int>(
                handler.BeginSend(byteData, 0, byteData.Length, 0, null, null),
                handler.EndSend
        );
    }

    public void Close()
    {
        Dispose();
    }

    public void Dispose()
    {
        foreach(Socket client in _clients.Values)
            client.Shutdown(SocketShutdown.Both);
        _listener.Close();
    }
}